var idsetd = charIDToTypeID( "setd" );
    var desc2 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
        var ref1 = new ActionReference();
        var idClr = charIDToTypeID( "Clr " );
        var idFrgC = charIDToTypeID( "FrgC" );
        ref1.putProperty( idClr, idFrgC );
    desc2.putReference( idnull, ref1 );
    var idT = charIDToTypeID( "T   " );
        var desc3 = new ActionDescriptor();
        var idH = charIDToTypeID( "H   " );
        var idAng = charIDToTypeID( "#Ang" );
        desc3.putUnitDouble( idH, idAng, 210.003662 );
        var idStrt = charIDToTypeID( "Strt" );
        desc3.putDouble( idStrt, 0.000000 );
        var idBrgh = charIDToTypeID( "Brgh" );
        desc3.putDouble( idBrgh, 0.000000 );
    var idHSBC = charIDToTypeID( "HSBC" );
    desc2.putObject( idT, idHSBC, desc3 );
executeAction( idsetd, desc2, DialogModes.NO );

// =======================================================
var idExch = charIDToTypeID( "Exch" );
    var desc4 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
        var ref2 = new ActionReference();
        var idClr = charIDToTypeID( "Clr " );
        var idClrs = charIDToTypeID( "Clrs" );
        ref2.putProperty( idClr, idClrs );
    desc4.putReference( idnull, ref2 );
executeAction( idExch, desc4, DialogModes.NO );

// =======================================================
var idsetd = charIDToTypeID( "setd" );
    var desc5 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
        var ref3 = new ActionReference();
        var idClr = charIDToTypeID( "Clr " );
        var idFrgC = charIDToTypeID( "FrgC" );
        ref3.putProperty( idClr, idFrgC );
    desc5.putReference( idnull, ref3 );
    var idT = charIDToTypeID( "T   " );
        var desc6 = new ActionDescriptor();
        var idH = charIDToTypeID( "H   " );
        var idAng = charIDToTypeID( "#Ang" );
        desc6.putUnitDouble( idH, idAng, 204.323730 );
        var idStrt = charIDToTypeID( "Strt" );
        desc6.putDouble( idStrt, 0.000000 );
        var idBrgh = charIDToTypeID( "Brgh" );
        desc6.putDouble( idBrgh, 100.000000 );
    var idHSBC = charIDToTypeID( "HSBC" );
    desc5.putObject( idT, idHSBC, desc6 );
executeAction( idsetd, desc5, DialogModes.NO );

// =======================================================
var idExch = charIDToTypeID( "Exch" );
    var desc7 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
        var ref4 = new ActionReference();
        var idClr = charIDToTypeID( "Clr " );
        var idClrs = charIDToTypeID( "Clrs" );
        ref4.putProperty( idClr, idClrs );
    desc7.putReference( idnull, ref4 );
executeAction( idExch, desc7, DialogModes.NO );

// =======================================================
var idsetd = charIDToTypeID( "setd" );
    var desc8 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
        var ref5 = new ActionReference();
        var idClr = charIDToTypeID( "Clr " );
        var idFrgC = charIDToTypeID( "FrgC" );
        ref5.putProperty( idClr, idFrgC );
    desc8.putReference( idnull, ref5 );
    var idT = charIDToTypeID( "T   " );
        var desc9 = new ActionDescriptor();
        var idRd = charIDToTypeID( "Rd  " );
        desc9.putDouble( idRd, 101.003891 );
        var idGrn = charIDToTypeID( "Grn " );
        desc9.putDouble( idGrn, 112.000000 );
        var idBl = charIDToTypeID( "Bl  " );
        desc9.putDouble( idBl, 123.003891 );
    var idRGBC = charIDToTypeID( "RGBC" );
    desc8.putObject( idT, idRGBC, desc9 );
executeAction( idsetd, desc8, DialogModes.NO );

// =======================================================
var idExch = charIDToTypeID( "Exch" );
    var desc10 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
        var ref6 = new ActionReference();
        var idClr = charIDToTypeID( "Clr " );
        var idClrs = charIDToTypeID( "Clrs" );
        ref6.putProperty( idClr, idClrs );
    desc10.putReference( idnull, ref6 );
executeAction( idExch, desc10, DialogModes.NO );

// =======================================================
var idsetd = charIDToTypeID( "setd" );
    var desc11 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
        var ref7 = new ActionReference();
        var idClr = charIDToTypeID( "Clr " );
        var idFrgC = charIDToTypeID( "FrgC" );
        ref7.putProperty( idClr, idFrgC );
    desc11.putReference( idnull, ref7 );
    var idT = charIDToTypeID( "T   " );
        var desc12 = new ActionDescriptor();
        var idRd = charIDToTypeID( "Rd  " );
        desc12.putDouble( idRd, 163.996109 );
        var idGrn = charIDToTypeID( "Grn " );
        desc12.putDouble( idGrn, 185.996109 );
        var idBl = charIDToTypeID( "Bl  " );
        desc12.putDouble( idBl, 201.000000 );
    var idRGBC = charIDToTypeID( "RGBC" );
    desc11.putObject( idT, idRGBC, desc12 );
executeAction( idsetd, desc11, DialogModes.NO );
