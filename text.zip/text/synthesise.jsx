function synthesise(fullCardName){
  // Load in json2.js, MTG JSON and some function files
  $.evalFile(filePath + "text/json2.js");

  $.evalFile(filePath + "text/insertManaAndItaliciseText.jsx");
  $.evalFile(filePath + "text/insertManaCost.jsx");
  $.evalFile(filePath + "text/excessFunctions.jsx");
  $.evalFile(filePath + "text/gradientUncommon.jsx");
  $.evalFile(filePath + "text/gradientRare.jsx");

  // Retrieve the card's name and artist
  var openIndex  = fullCardName.lastIndexOf(" (");
  var closeIndex = fullCardName.lastIndexOf(")");
  var cardArtist = fullCardName.slice(openIndex+2,closeIndex);
  var cardName   = fullCardName.slice(0,openIndex);
  var scriptFile = new File(filePath + "text/AllSets.json");
  scriptFile.open('r');
  var content = scriptFile.read();
  scriptFile.close();

  // Find our card name in the database
  //alert(cardName);
  var namePrefix = "\"name\": \"";
  var nameConcat = namePrefix.concat(cardName);
  var indicesOfName = getAllIndexes(content, nameConcat.concat("\","));
  // Grab the oldest printing of the card I think?
  var indexesOfID = [];
  var multiverseIDs = [];
  //alert(nameConcat.concat("\","));
  for(var i=0;i<indicesOfName.length;i++){
    indexesOfID[i] = content.lastIndexOf("\"multiverseid\": ", indicesOfName[i]);
    var indexOfComma = content.indexOf(",",indexesOfID[i]);
    var indexOfCode = content.indexOf("\"code\": ",indexOfComma);
    multiverseIDs.push(content.slice(indexesOfID[i]+16,indexOfComma));
  }

  // Create a copy of the multiverse ID array
  var multiverseIDsCopy = multiverseIDs.slice(0);

  // Sort the copy into ascending order (oldest to newest in terms of printing
  // age) and store that as smallestID
  var smallestID = multiverseIDsCopy.sort(function (a,b) {return a-b;});

  // Store the multiverse ID of the oldest printing as CompletelyNew
  var CompletelyNew = smallestID[0];

  // Store the index in multiverseIDs of that ID as SecondCompletelyNew
  var SecondCompletelyNew = arrayIndexOf2(multiverseIDs,CompletelyNew,0);

  // originalExpansionIndex is the index of the 3 letter code used to represent
  // the expansion that the card originally hails from
  var originalExpansionIndex = content.lastIndexOf("\"code\": \"",indicesOfName[SecondCompletelyNew]);
  var indexOfComma = content.indexOf(",",originalExpansionIndex);

  // Slice and dice to get the 3 letter expansion code
  var originalExpansion = content.slice(originalExpansionIndex + 9, indexOfComma - 1);

  // Find where the JSON for the card's entry in this set begins and ends
  var manaCostIndex = content.lastIndexOf("cmc",indicesOfName[SecondCompletelyNew]);
  var typeIndex = content.indexOf("\"types\": ",indicesOfName[SecondCompletelyNew]);
  var startingIndexOfCard = content.lastIndexOf("{",manaCostIndex);
  var endingIndexOfCard = content.indexOf("}",typeIndex);

  // Slice and dice, then parse the result, for the complete JSON.
  var jsonString = content.slice(startingIndexOfCard,endingIndexOfCard+1);

  // Grab the watermark glyph pls
  // Grab the card's original rarity while we're here
  var jsonParsed = JSON.parse(jsonString);

  var cardRarity = jsonParsed.rarity;

  var scriptFile = new File(filePath + "text/symbols.json");
  scriptFile.open('r');
  var contentGlyphs = scriptFile.read();
  scriptFile.close();
  var jsonGlyphs = JSON.parse(contentGlyphs);
  var originalexpansionlowercase = originalExpansion.toLowerCase();
  var myGlyph = jsonGlyphs[originalexpansionlowercase];

  // Also retrieve the flavour text for the oldest printing with flavour text
  var flavourText = "";
  if(jsonString.lastIndexOf("\"flavor\": ") >= 0){
    var jsonParsed = JSON.parse(jsonString);
    flavourText = jsonParsed.flavor;
  }
  else{
    for(var i=1;i<multiverseIDs.length;i++){
      // Grab the current multiverse ID
      var multiverseThing = arrayIndexOf2(multiverseIDs,smallestID[i],0);

      // Slice and dice, my dudes
      var manaCostIndex = content.lastIndexOf("cmc",indicesOfName[multiverseThing]);
      var typeIndex = content.indexOf("\"types\": ",indicesOfName[multiverseThing]);
      var startingIndexOfCard = content.lastIndexOf("{",manaCostIndex);
      var endingIndexOfCard = content.indexOf("}",typeIndex);
      var jsonString = content.slice(startingIndexOfCard,endingIndexOfCard+1);

      // Check if this fella has flavour text at all
      if(jsonString.lastIndexOf("\"flavor\": ") >= 0){
        var jsonParsed = JSON.parse(jsonString);
        flavourText = jsonParsed.flavor;
        break;
      }
    }
  }
  var jsonParsed = JSON.parse(jsonString);

  // Retrieve some more info about the card.
  var typeLine = jsonParsed.type;
  var cardPower = jsonParsed.power;
  var cardTough = jsonParsed.toughness;
  var cardText = jsonParsed.text;

  // Rarity gradient
  if(cardRarity == "Uncommon"){
    gradientUncommon();
  }
  else if(cardRarity == "Rare"){
    gradientRare();
  }
  if(cardText == undefined){
    cardText == "";
  }
  var cardManaCost = jsonParsed.manaCost;
  if(jsonString.indexOf("colorIdentity") >= 0 && typeLine.indexOf("Artifact") < 0){
    var str = String(jsonParsed.colorIdentity);
    var regex = /[.,\s]/g;
    var colourIdentity = String(str.replace(regex,''));
  }
  else{
    var colourIdentity = "";
  }

  //---------- Card Name ----------
  // Select the name layer
  var myLayer = docRef.layers.getByName("Text and Icons");
  var mySubLayer = myLayer.layers.getByName("Card Name");
  docRef.activeLayer = mySubLayer;
  docRef.activeLayer.textItem.contents = cardName;

  // ---------- Typeline ----------
  // Select the typeline layer
  var myLayer = docRef.layers.getByName("Text and Icons");
  var mySubLayer = myLayer.layers.getByName("Typeline");
  docRef.activeLayer = mySubLayer;
  docRef.activeLayer.textItem.contents = typeLine;

  // ---------- P / T ----------
  var myLayer = docRef.layers.getByName("Text and Icons");
  var mySubLayer = myLayer.layers.getByName("Power / Toughness");
  docRef.activeLayer = mySubLayer;
  if(typeLine.indexOf("Creature") >= 0){
    docRef.activeLayer.textItem.contents = cardPower + "/" + cardTough;
  }
  else{
    docRef.activeLayer.visible = false;
  }

  // ---------- Artist ----------
  replaceText("Artist", cardArtist);

  // ---------- Card Frame ----------
  // First see if the card is land or nonland
  if(typeLine.indexOf("Land") >= 0){
    // Hide the mana cost while we're at it
    var myLayer = docRef.layers.getByName("Text and Icons");
    var mySubLayer = myLayer.layers.getByName("Mana Cost");
    docRef.activeLayer = mySubLayer;
    docRef.activeLayer.visible = false;
    // Choose the land folder
    var myLayer = docRef.layers.getByName("Land");
    if(cardText.indexOf("any color") >= 0){
      colourIdentity = "WUBRG";
    }
    if(cardText.indexOf(" Plains ") >= 0){
      colourIdentity = colourIdentity + "W";
    }
    if(cardText.indexOf(" Island ") >= 0){
      colourIdentity = colourIdentity + "U";
    }
    if(cardText.indexOf(" Swamp ") >= 0){
      colourIdentity = colourIdentity + "B";
    }
    if(cardText.indexOf(" Mountain ") >= 0){
      colourIdentity = colourIdentity + "R";
    }
    if(cardText.indexOf(" Forest ") >= 0){
      colourIdentity = colourIdentity + "G";
    }
  }
  else{
    // ---------- Mana Cost ----------
    myManaLayer = docRef.layers.getByName("Text and Icons");
    manaCostLayer = myManaLayer.layers.getByName("Mana Cost");
    manaCostLayer.textItem.contents = cardManaCost;
    insertManaCost(cardManaCost);

    var myLayer = docRef.layers.getByName("Nonland");
    if(colourIdentity.valueOf() == "B"){
      // Change the text colour of the artist, legal and P/T layers to white
      var myTextLayer = docRef.layers.getByName("Legal");
      var myNewTextLayer = myTextLayer.layers.getByName("Artist");
      textColour = new SolidColor();
      textColour.rgb.red = 255;
      textColour.rgb.blue = 255;
      textColour.rgb.green = 255;
      myNewTextLayer.textItem.color = textColour;
      myNewTextLayer = myTextLayer.layers.getByName("Legal");
      myNewTextLayer.textItem.color = textColour;
      myTextLayer = docRef.layers.getByName("Text and Icons");
      myNewTextLayer = myTextLayer.layers.getByName("Power / Toughness");
      myNewTextLayer.textItem.color = textColour;
    }
  }
  if(colourIdentity.length > 2){
    var mySubLayer = myLayer.layers.getByName("WUBRG");
  }
  else if(colourIdentity.length <= 0){
    var mySubLayer = myLayer.layers.getByName("C");
  }
  else if(colourIdentity.length == 2){
    if(colourIdentity == "WU" || colourIdentity == "UW"){
      var mySubLayer = myLayer.layers.getByName("WU");
    }
    else if(colourIdentity == "UB" || colourIdentity == "BU"){
      var mySubLayer = myLayer.layers.getByName("UB");
    }
    else if(colourIdentity == "BR" || colourIdentity == "RB"){
      var mySubLayer = myLayer.layers.getByName("BR");
    }
    else if(colourIdentity == "RG" || colourIdentity == "GR"){
      var mySubLayer = myLayer.layers.getByName("RG");
    }
    else if(colourIdentity == "GW" || colourIdentity == "WG"){
      var mySubLayer = myLayer.layers.getByName("GW");
    }
    else if(colourIdentity == "WB" || colourIdentity == "BW"){
      var mySubLayer = myLayer.layers.getByName("WB");
    }
    else if(colourIdentity == "BG" || colourIdentity == "GB"){
      var mySubLayer = myLayer.layers.getByName("BG");
    }
    else if(colourIdentity == "GU" || colourIdentity == "UG"){
      var mySubLayer = myLayer.layers.getByName("GU");
    }
    else if(colourIdentity == "UR" || colourIdentity == "RU"){
      var mySubLayer = myLayer.layers.getByName("UR");
    }
    else if(colourIdentity == "RW" || colourIdentity == "WR"){
      var mySubLayer = myLayer.layers.getByName("RW");
    }
  }
  else{
    var mySubLayer = myLayer.layers.getByName(colourIdentity);
  }
  docRef.activeLayer = mySubLayer;
  docRef.activeLayer.visible = true;

  // ---------- Watermark ----------
  var watermarkLayer = mySubLayer.layers.getByName("Watermark");
  docRef.activeLayer = watermarkLayer;
  docRef.activeLayer.visible = true;
  docRef.activeLayer.textItem.contents = myGlyph;

  // ---------- Rules Text ----------
  var myLayer = docRef.layers.getByName("Text and Icons");
  var myNewLayer = myLayer.layers.getByName("Rules Text");
  docRef.activeLayer = myNewLayer;
  if(cardText !== undefined){
    cardText = cardText.replace(/\n/g,"\r");
  }
  else{
    cardText = "";
  }
  docRef.activeLayer.textItem.contents = cardText;

  // ---------- Italics Text ----------
  // Build an array of italics text, starting with identifying any
  // reminder text in the card's text body (anything in brackets).
  var reminderTextBool = 1;

  var italicText = []; var endIndex = 0;
  while(reminderTextBool == 1){
    var startIndex = cardText.indexOf("(",endIndex);
    if(startIndex >= 0){
      endIndex = cardText.indexOf(")",startIndex+1);
      italicText.push( cardText.slice(startIndex, endIndex+1) );
    }
    else{
      reminderTextBool = 0;
    }
  }

  // Also attach the ability word Threshold and the cards' flavour text
  // to the italics array.
  var flavourIndex = -1;
  italicText.push("Threshold");
  if(flavourText.length > 1){
    flavourText = flavourText.replace(/\n/g,"\r");
    italicText.push(flavourText);
    flavourIndex = cardText.length;
  }
  // Jam the rules text and flavour text together
  if(flavourText.length > 0){
    var completeString = cardText + "\r" + flavourText;
  }
  else{
    var completeString = cardText;
  }
  insertManaAndItaliciseText(completeString, italicText, flavourIndex);

  // Maybe centre justify the text box
  if(flavourText.length <= 1 && cardText.length <= 70){
    // Here we go boys
    docRef.activeLayer.textItem.justification = Justification.CENTER;
  }

  // Scale the text to fit in the text box
  scaleTextToFitBoxNew(myNewLayer);

  // Vertically align text — Pulled from script listener
  verticallyAlignText();

  // ----------Save as PNG in the out folder ----------
  var idsave = charIDToTypeID( "save" );
      var desc3 = new ActionDescriptor();
      var idAs = charIDToTypeID( "As  " );
          var desc4 = new ActionDescriptor();
          var idPGIT = charIDToTypeID( "PGIT" );
          var idPGIT = charIDToTypeID( "PGIT" );
          var idPGIN = charIDToTypeID( "PGIN" );
          desc4.putEnumerated( idPGIT, idPGIT, idPGIN );
          var idPNGf = charIDToTypeID( "PNGf" );
          var idPNGf = charIDToTypeID( "PNGf" );
          var idPGAd = charIDToTypeID( "PGAd" );
          desc4.putEnumerated( idPNGf, idPNGf, idPGAd );
      var idPNGF = charIDToTypeID( "PNGF" );
      desc3.putObject( idAs, idPNGF, desc4 );
      var idIn = charIDToTypeID( "In  " );
      var filename = filePath + '/out/' + cardName + '.png';
      desc3.putPath( idIn, new File( filename ) );
      var idCpy = charIDToTypeID( "Cpy " );
      desc3.putBoolean( idCpy, true );
  executeAction( idsave, desc3, DialogModes.NO );

  // Close the thing without saving
  docRef.close(SaveOptions.DONOTSAVECHANGES);
  $.evalFile(filePath + "text/borderify.jsx");
}
